# **Проект 4: Место**
[https://at0m234.github.io/mesto/index.html]
### Обзор

* Figma 
* Картинки

**Figma**

* [Ссылка на макет в Figma Проект 4](https://www.figma.com/file/StZjf8HnoeLdiXS7dYrLAh/JavaScript.-Sprint-4)
* [Ссылка на макет в Figma Проект 5](https://www.figma.com/file/nlYpT4VhFiwimn2YlncrcF/JavaScript.-Sprint-5?node-id=0%3A1)

**Картинки**

Доставать картинки предстоит из Фигмы. Это расхожая практика, поэтому полезно потренироваться.
Не забудьте [оптимизировать картинки](https://tinypng.com/), чтобы ваш сайт загружался быстрее.

Удачи!
